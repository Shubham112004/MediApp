package com.medireminder.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao interface MedicineDao {
    @Transaction @Query("SELECT * FROM medicines ORDER BY active DESC, name COLLATE NOCASE") fun observeAll(): Flow<List<MedicineWithSchedule>>
    @Query("SELECT * FROM medicines WHERE id=:id") suspend fun get(id: Long): Medicine?
    @Query("SELECT * FROM medicines WHERE active=1") suspend fun active(): List<Medicine>
    @Insert suspend fun insert(medicine: Medicine): Long
    @Update suspend fun update(medicine: Medicine)
    @Delete suspend fun delete(medicine: Medicine)
    @Insert suspend fun insertSchedule(schedule: MedicationSchedule): Long
    @Update suspend fun updateSchedule(schedule: MedicationSchedule)
    @Query("SELECT * FROM schedules WHERE medicineId=:medicineId") suspend fun schedules(medicineId: Long): List<MedicationSchedule>
    @Query("DELETE FROM schedules WHERE medicineId=:medicineId") suspend fun deleteSchedules(medicineId: Long)
}

@Dao interface DoseDao {
    @Query("SELECT * FROM dose_records WHERE scheduledAt >= :from AND scheduledAt < :to ORDER BY scheduledAt") fun observeRange(from: Long, to: Long): Flow<List<DoseRecord>>
    @Query("SELECT * FROM dose_records WHERE medicineId=:medicineId ORDER BY scheduledAt DESC LIMIT 30") suspend fun recent(medicineId: Long): List<DoseRecord>
    @Query("SELECT * FROM dose_records WHERE occurrenceId=:key LIMIT 1") suspend fun getOccurrence(key: String): DoseRecord?
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(record: DoseRecord): Long
    @Update suspend fun update(record: DoseRecord)
    @Query("UPDATE dose_records SET status=:status, confirmedAt=:confirmedAt, skipReason=:reason, originalStatus=CASE WHEN originalStatus='' THEN status ELSE originalStatus END WHERE occurrenceId=:key") suspend fun updateStatus(key: String, status: String, confirmedAt: Long?, reason: String)
    @Query("SELECT * FROM dose_records WHERE scheduledAt BETWEEN :from AND :to") suspend fun inRange(from: Long, to: Long): List<DoseRecord>
}

@Dao interface SettingsDao {
    @Query("SELECT * FROM app_settings WHERE id=1") fun observe(): Flow<AppSettings?>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(settings: AppSettings)
    @Query("SELECT * FROM app_settings WHERE id=1") suspend fun get(): AppSettings?
}
