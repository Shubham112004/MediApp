package com.medireminder.reminder

import android.app.*
import android.content.*
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.medireminder.MediReminderApp
import com.medireminder.data.MedicineRepository
import kotlinx.coroutines.*

const val CHANNEL_ID = "medicine_reminders"
class ReminderScheduler(private val context: Context, private val repository: MedicineRepository) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    fun scheduleOccurrence(key: String, name: String, dose: String, at: Long) {
        val requestId = key.hashCode()
        val intent = Intent(context, ReminderReceiver::class.java).apply { putExtra("occurrence", key); putExtra("name", name); putExtra("dose", dose); putExtra("at", at) }
        val pi = PendingIntent.getBroadcast(context, requestId, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try { if (Build.VERSION.SDK_INT >= 23) { if (Build.VERSION.SDK_INT < 31 || alarmManager.canScheduleExactAlarms()) alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) else alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) } else alarmManager.setExact(AlarmManager.RTC_WAKEUP, at, pi) } catch (_: SecurityException) { alarmManager.set(AlarmManager.RTC_WAKEUP, at, pi) }
    }
    fun cancel(key: String) { val i=Intent(context, ReminderReceiver::class.java); PendingIntent.getBroadcast(context,key.hashCode(),i,PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)?.let(alarmManager::cancel) }
    companion object { fun createChannel(context: Context) { if (Build.VERSION.SDK_INT >= 26) { val c=NotificationChannel(CHANNEL_ID,"Medicine reminders",NotificationManager.IMPORTANCE_HIGH).apply { description="Scheduled medicine reminders" }; (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(c) } } }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.createChannel(context)
        val key=intent.getStringExtra("occurrence") ?: return
        val name=intent.getStringExtra("name") ?: "Medicine"
        val dose=intent.getStringExtra("dose") ?: ""
        val at=intent.getLongExtra("at",System.currentTimeMillis())
        val taken=PendingIntent.getBroadcast(context, (key+"taken").hashCode(), Intent(context,ActionReceiver::class.java).setAction("TAKEN").putExtra("key",key), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val skipped=PendingIntent.getBroadcast(context, (key+"skip").hashCode(), Intent(context,ActionReceiver::class.java).setAction("SKIP").putExtra("key",key), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val snooze=PendingIntent.getBroadcast(context, (key+"snooze").hashCode(), Intent(context,ActionReceiver::class.java).setAction("SNOOZE").putExtra("key",key).putExtra("name",name).putExtra("dose",dose).putExtra("at",at), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n=NotificationCompat.Builder(context,CHANNEL_ID).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Time for $name").setContentText(dose).setStyle(NotificationCompat.BigTextStyle().bigText("Scheduled reminder • $dose
Please follow your prescription instructions." )).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).addAction(0,"Taken",taken).addAction(0,"Snooze",snooze).addAction(0,"Skip",skipped).build()
        try { NotificationManagerCompat.from(context).notify(key.hashCode(),n) } catch (_: SecurityException) { }
    }
}
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val key=intent.getStringExtra("key") ?: return
        val app=context.applicationContext as MediReminderApp
        val pending=goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                when(intent.action) {
                    "TAKEN" -> app.repository.recordDose(key,"TAKEN")
                    "SKIP" -> app.repository.recordDose(key,"SKIPPED")
                    "SNOOZE" -> {
                        val name=intent.getStringExtra("name") ?: "Medicine"; val dose=intent.getStringExtra("dose") ?: ""; val at=System.currentTimeMillis()+10*60_000L
                        ReminderScheduler(context,app.repository).scheduleOccurrence(key,name,dose,at)
                    }
                }
                NotificationManagerCompat.from(context).cancel(key.hashCode())
            } finally { pending.finish() }
        }
    }
}
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app=context.applicationContext as MediReminderApp
        val pending=goAsync()
        CoroutineScope(Dispatchers.IO).launch { try { app.repository.reconcileFuture() } finally { pending.finish() } }
    }
}
