package com.medireminder.data

import androidx.room.*

@Entity(tableName = "medicines")
data class Medicine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val strength: String = "",
    val form: String = "Tablet",
    val doseAmount: String,
    val doseUnit: String,
    val foodInstructions: String = "Unspecified",
    val notes: String = "",
    val startDate: String,
    val endDate: String = "",
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "schedules", foreignKeys = [ForeignKey(entity = Medicine::class, parentColumns = ["id"], childColumns = ["medicineId"], onDelete = ForeignKey.CASCADE)], indices = [Index("medicineId")])
data class MedicationSchedule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val medicineId: Long,
    val frequency: String = "Daily",
    val weekdays: String = "1,2,3,4,5,6,7",
    val times: String,
    val enabled: Boolean = true
)

@Entity(tableName = "dose_records", indices = [Index("medicineId"), Index(value = ["occurrenceId"], unique = true), Index("scheduledAt")])
data class DoseRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val medicineId: Long,
    val scheduleId: Long,
    val occurrenceId: String,
    val scheduledAt: Long,
    val status: String = "UPCOMING",
    val confirmedAt: Long? = null,
    val skipReason: String = "",
    val originalStatus: String = ""
)

@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey val id: Int = 1,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val snoozeMinutes: Int = 10,
    val graceMinutes: Int = 60,
    val theme: String = "System"
)

data class MedicineWithSchedule(@Embedded val medicine: Medicine, @Relation(parentColumn = "id", entityColumn = "medicineId") val schedules: List<MedicationSchedule>)
