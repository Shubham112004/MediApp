package com.medireminder

import android.app.Application
import com.medireminder.data.MediDatabase
import com.medireminder.data.MedicineRepository
import com.medireminder.reminder.ReminderScheduler

class MediReminderApp : Application() {
    val database by lazy { MediDatabase.get(this) }
    val repository by lazy { MedicineRepository(database.medicineDao(), database.doseDao(), this) }
    val scheduler by lazy { ReminderScheduler(this, repository) }
}
