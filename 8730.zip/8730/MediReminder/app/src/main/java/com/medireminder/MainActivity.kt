package com.medireminder

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.medireminder.data.*
import kotlinx.coroutines.launch
import java.time.*
import java.time.format.DateTimeFormatter

private val Teal = Color(0xFF087F8C)
class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        (application as MediReminderApp).let { ReminderInit.init(it) }
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { MediTheme { MediApp((application as MediReminderApp).repository) } }
    }
}
object ReminderInit { fun init(app: MediReminderApp) { com.medireminder.reminder.ReminderScheduler.createChannel(app); androidx.work.WorkManager.getInstance(app).enqueueUniqueWork("reconcile_reminders", androidx.work.ExistingWorkPolicy.REPLACE, androidx.work.OneTimeWorkRequestBuilder<ReconcileWorker>().build()) } }
class ReconcileWorker(ctx: android.content.Context, params: androidx.work.WorkerParameters): androidx.work.CoroutineWorker(ctx,params) { override suspend fun doWork(): Result { return try { (applicationContext as MediReminderApp).repository.reconcileFuture(); Result.success() } catch (_: Exception) { Result.retry() } } }

@Composable fun MediTheme(content: @Composable () -> Unit) { val scheme=lightColorScheme(primary=Teal, secondary=Color(0xFF4D777C), background=Color(0xFFF5F9F9), surface=Color.White); MaterialTheme(colorScheme=scheme, content=content) }

@Composable fun MediApp(repo: MedicineRepository) {
    val medicines by repo.medicines.collectAsStateWithLifecycle(initialValue=emptyList())
    val settings by repo.settings.collectAsStateWithLifecycle(initialValue=AppSettings())
    var tab by remember { mutableStateOf("Home") }; var editing by remember { mutableStateOf<MedicineWithSchedule?>(null) }; var add by remember { mutableStateOf(false) }; var detail by remember { mutableStateOf<MedicineWithSchedule?>(null) }
    Scaffold(containerColor=MaterialTheme.colorScheme.background, bottomBar={ if(!add && detail==null) NavigationBar { listOf("Home","Medicines","History","Settings").forEach { item -> NavigationBarItem(selected=tab==item,onClick={tab=item},icon={ Icon(when(item){"Home"->Icons.Default.Home;"Medicines"->Icons.Default.Medication;"History"->Icons.Default.History;else->Icons.Default.Settings},null) },label={Text(item)}) } } }, floatingActionButton={ if(!add && detail==null && tab!="Settings") FloatingActionButton(onClick={editing=null;add=true},containerColor=Teal,contentColor=Color.White){Icon(Icons.Default.Add,"Add medicine")} }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=18.dp)) {
            when {
                add -> MedicineForm(existing=editing, onCancel={add=false;editing=null}, onSave={ _, _, _, _ -> Unit }, repository=repo, onDone={add=false;editing=null})
                detail!=null -> MedicineDetail(detail!!, repo, onBack={detail=null}, onEdit={editing=detail;detail=null;add=true})
                tab=="Home" -> HomeScreen(medicines, repo, onDetail={detail=it}, settings)
                tab=="Medicines" -> MedicinesScreen(medicines,onDetail={detail=it},onAdd={add=true})
                tab=="History" -> HistoryScreen(medicines,repo)
                else -> SettingsScreen(settings,repo)
            }
        }
    }
}

@Composable fun Header(title:String, subtitle:String="") { Spacer(Modifier.height(18.dp)); Text(title, fontSize=28.sp,fontWeight=FontWeight.Bold,color=Color(0xFF17383C)); if(subtitle.isNotBlank()) { Spacer(Modifier.height(4.dp)); Text(subtitle,color=Color(0xFF657A7D),fontSize=14.sp) }; Spacer(Modifier.height(16.dp)) }
@Composable fun SurfaceCard(content:@Composable ColumnScope.()->Unit) { Card(Modifier.fillMaxWidth().padding(bottom=12.dp),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(defaultElevation=1.dp)){Column(Modifier.padding(16.dp),content=content)} }

@Composable fun HomeScreen(medicines:List<MedicineWithSchedule>,repo:MedicineRepository,onDetail:(MedicineWithSchedule)->Unit,settings:AppSettings) {
    val today=LocalDate.now(); val from=today.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli(); val to=today.plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    val doses by repo.doses(from,to).collectAsStateWithLifecycle(initialValue=emptyList())
    val active=medicines.filter{it.medicine.active}; val now=System.currentTimeMillis(); val done=doses.count{it.status=="TAKEN"}; val percent=if(doses.isEmpty()) 0f else done.toFloat()/doses.size
    LazyColumn { item { Header("Good ${if(LocalTime.now().hour<12) "morning" else if(LocalTime.now().hour<18) "afternoon" else "evening"}",today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM"))) }
        item { SurfaceCard { Text("TODAY'S PROGRESS",fontSize=12.sp,fontWeight=FontWeight.Bold,color=Teal); Spacer(Modifier.height(8.dp)); Row(verticalAlignment=Alignment.CenterVertically){ Text("$done",fontSize=32.sp,fontWeight=FontWeight.Bold); Text(" / ${doses.size} doses taken",color=Color.Gray) }; Spacer(Modifier.height(8.dp)); LinearProgressIndicator(progress={percent},modifier=Modifier.fillMaxWidth().height(8.dp),color=Teal,trackColor=Color(0xFFE0EEEE)) } }
        item { Text("Today's schedule",fontSize=20.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=8.dp)) }
        if(active.isEmpty()) item { SurfaceCard { Icon(Icons.Default.Medication,null,tint=Teal,modifier=Modifier.size(36.dp)); Spacer(Modifier.height(8.dp)); Text("Your medicines, all in one place",fontWeight=FontWeight.Bold,fontSize=18.sp); Text("Add your first medicine to start receiving reminders.",color=Color.Gray); Spacer(Modifier.height(8.dp)); Text("+ Add medicine",color=Teal,fontWeight=FontWeight.Bold) } }
        items(active,key={it.medicine.id}) { item -> SurfaceCard { Row(verticalAlignment=Alignment.CenterVertically){ Column(Modifier.weight(1f)){Text(item.medicine.name,fontSize=18.sp,fontWeight=FontWeight.Bold); Text("${item.medicine.doseAmount} ${item.medicine.doseUnit} ${if(item.medicine.strength.isNotBlank()) "• ${item.medicine.strength}" else ""}",color=Color.Gray); Text(item.schedules.joinToString { it.times.split(",").joinToString(" · ") },color=Teal,fontSize=13.sp) }; IconButton(onClick={onDetail(item)}){Icon(Icons.Default.ChevronRight,"Medicine details")} } } }
        item { Spacer(Modifier.height(70.dp)) }
    }
}
@Composable fun MedicinesScreen(medicines:List<MedicineWithSchedule>,onDetail:(MedicineWithSchedule)->Unit,onAdd:()->Unit) { Column { Header("Medicines","Your saved medication schedules"); if(medicines.isEmpty()) SurfaceCard { Text("No medicines added yet."); Button(onClick=onAdd){Text("Add medicine")} } else LazyColumn { items(medicines,key={it.medicine.id}) { m -> SurfaceCard { Row(verticalAlignment=Alignment.CenterVertically){ Column(Modifier.weight(1f)){Text(m.medicine.name,fontSize=18.sp,fontWeight=FontWeight.Bold);Text(if(m.medicine.active) "Active" else "Paused",color=if(m.medicine.active) Teal else Color.Gray);Text(m.schedules.joinToString { it.times },color=Color.Gray) }; IconButton(onClick={onDetail(m)}){Icon(Icons.Default.ChevronRight,"Details")} } } } } } }

@Composable fun MedicineForm(existing:MedicineWithSchedule?,onCancel:()->Unit,onSave:(Medicine,String,String,String)->Unit,repository:MedicineRepository,onDone:()->Unit) {
    val scope= rememberCoroutineScope(); val old=existing?.medicine
    var name by remember { mutableStateOf(old?.name ?: "") }; var strength by remember { mutableStateOf(old?.strength ?: "") }; var amount by remember { mutableStateOf(old?.doseAmount ?: "") }; var unit by remember { mutableStateOf(old?.doseUnit ?: "tablet(s)") }; var form by remember { mutableStateOf(old?.form ?: "Tablet") }; var times by remember { mutableStateOf(existing?.schedules?.firstOrNull()?.times ?: "08:00") }; var frequency by remember { mutableStateOf(existing?.schedules?.firstOrNull()?.frequency ?: "Daily") }; var weekdays by remember { mutableStateOf(existing?.schedules?.firstOrNull()?.weekdays ?: "1,2,3,4,5,6,7") }; var start by remember { mutableStateOf(old?.startDate ?: LocalDate.now().toString()) }; var end by remember { mutableStateOf(old?.endDate ?: "") }; var food by remember { mutableStateOf(old?.foodInstructions ?: "Unspecified") }; var notes by remember { mutableStateOf(old?.notes ?: "") }; var error by remember { mutableStateOf("") }; var saving by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) { Row(verticalAlignment=Alignment.CenterVertically){ IconButton(onClick=onCancel){Icon(Icons.Default.ArrowBack,"Back")}; Text(if(old==null) "Add medicine" else "Edit medicine",fontSize=24.sp,fontWeight=FontWeight.Bold) }; Spacer(Modifier.height(8.dp)); if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            FormField("Medicine name *",name,{name=it},"e.g. Medicine name")
            FormField("Strength (optional)",strength,{strength=it},"e.g. 500 mg")
            FormField("Dose amount *",amount,{amount=it},"e.g. 1 or 5")
            Text("Dose unit *",fontWeight=FontWeight.Bold); ChoiceRow(listOf("tablet(s)","capsule(s)","mL","drop(s)","puff(s)","injection","other"),unit){unit=it}
            Text("Medicine form",fontWeight=FontWeight.Bold); ChoiceRow(listOf("Tablet","Capsule","Liquid","Drops","Inhaler","Injection","Other"),form){form=it}
            FormField("Reminder time(s) *",times,{times=it},"08:00, 14:00, 20:00")
            Text("Use 24-hour times separated by commas.",fontSize=12.sp,color=Color.Gray)
            Text("Frequency",fontWeight=FontWeight.Bold); ChoiceRow(listOf("Daily","Selected weekdays"),frequency){frequency=it}
            if(frequency=="Selected weekdays") { Text("Choose weekdays (Mon–Sun)"); Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){ listOf("M" to 1,"T" to 2,"W" to 3,"T" to 4,"F" to 5,"S" to 6,"S" to 7).forEach { (label,day)-> FilterChip(selected=weekdays.split(",").contains(day.toString()),onClick={val set=weekdays.split(",").filter{it.isNotBlank()}.toMutableSet(); if(!set.add(day.toString())) set.remove(day.toString()); weekdays=set.sorted().joinToString(",")},label={Text(label)}) } } }
            FormField("Start date (YYYY-MM-DD) *",start,{start=it},"${LocalDate.now()}")
            FormField("End date (optional)",end,{end=it},"Leave blank for ongoing")
            Text("Food instructions",fontWeight=FontWeight.Bold); ChoiceRow(listOf("Unspecified","Before food","After food","With food"),food){food=it}
            FormField("Notes (optional)",notes,{notes=it},"Additional instructions")
            Spacer(Modifier.height(16.dp))
        }
        Button(onClick={
            val validTimes=times.split(",").map{it.trim()}.all { runCatching{LocalTime.parse(it)}.isSuccess }
            if(name.isBlank() || amount.isBlank() || times.isBlank()) error="Please enter medicine name, dose amount and at least one reminder time."
            else if(!validTimes) error="Enter times in 24-hour format, e.g. 08:00, 20:30."
            else if(runCatching{LocalDate.parse(start)}.isFailure || (end.isNotBlank() && runCatching{LocalDate.parse(end)}.isFailure)) error="Dates must use YYYY-MM-DD format."
            else { saving=true; error=""; scope.launch { try { val m=Medicine(id=old?.id?:0,name=name.trim(),strength=strength.trim(),form=form,doseAmount=amount.trim(),doseUnit=unit,foodInstructions=food,notes=notes,startDate=start,endDate=end,active=old?.active?:true,createdAt=old?.createdAt?:System.currentTimeMillis()); if(old==null) repository.add(m,times,frequency,weekdays) else repository.edit(m,times,frequency,weekdays); repository.reconcileFuture(); onDone() } catch(e:Exception){error="Could not save medicine. Please try again.";saving=false} } }
        },enabled=!saving,modifier=Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(16.dp)){Text(if(saving) "Saving…" else "Save medicine")} ; Spacer(Modifier.height(8.dp))
    }
}
@Composable fun FormField(label:String,value:String,onValue:(String)->Unit,placeholder:String) { Column(Modifier.padding(vertical=6.dp)){Text(label,fontWeight=FontWeight.Bold,fontSize=14.sp); OutlinedTextField(value=value,onValueChange=onValue,modifier=Modifier.fillMaxWidth(),placeholder={Text(placeholder)},singleLine=true,shape=RoundedCornerShape(14.dp))} }
@Composable fun ChoiceRow(options:List<String>,selected:String,onSelect:(String)->Unit){ Column { options.chunked(3).forEach { group -> Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){group.forEach { o -> FilterChip(selected=selected==o,onClick={onSelect(o)},label={Text(o,fontSize=12.sp)}) } } } } }

@Composable fun MedicineDetail(item:MedicineWithSchedule,repo:MedicineRepository,onBack:()->Unit,onEdit:()->Unit) {
    val scope= rememberCoroutineScope(); var confirmDelete by remember { mutableStateOf(false) }; var history by remember { mutableStateOf(emptyList<DoseRecord>()) }; LaunchedEffect(item.medicine.id){history=repo.recent(item.medicine.id)}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) { Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Back")};Text("Medicine details",fontSize=23.sp,fontWeight=FontWeight.Bold)}; SurfaceCard { Text(item.medicine.name,fontSize=26.sp,fontWeight=FontWeight.Bold); if(item.medicine.strength.isNotBlank()) Text("Strength: ${item.medicine.strength}"); Text("Dose: ${item.medicine.doseAmount} ${item.medicine.doseUnit}"); Text("Form: ${item.medicine.form}"); Text("Food: ${item.medicine.foodInstructions}"); Text("Schedule: ${item.schedules.joinToString { "${it.frequency} • ${it.times}" }}"); Text("Start: ${item.medicine.startDate}"); Text("End: ${item.medicine.endDate.ifBlank { "Ongoing" }}"); if(item.medicine.notes.isNotBlank()) Text("Notes: ${item.medicine.notes}") }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick=onEdit,modifier=Modifier.weight(1f)){Text("Edit")}; OutlinedButton(onClick={scope.launch {repo.setActive(item.medicine,!item.medicine.active);onBack()}},modifier=Modifier.weight(1f)){Text(if(item.medicine.active) "Pause" else "Resume")}; OutlinedButton(onClick={confirmDelete=true}){Text("Delete")} }
        Text("Recent dose history",fontWeight=FontWeight.Bold,fontSize=19.sp,modifier=Modifier.padding(vertical=12.dp)); history.forEach { r -> SurfaceCard { Text(InstantFormat(r.scheduledAt)); Text(r.status); if(r.confirmedAt!=null) Text("Confirmed: ${InstantFormat(r.confirmedAt)}") } }; Spacer(Modifier.height(30.dp))
    }
    if(confirmDelete) AlertDialog(onDismissRequest={confirmDelete=false},title={Text("Delete medicine?")},text={Text("This removes the medicine and its future schedule. Existing dose history remains on this device.")},confirmButton={TextButton(onClick={scope.launch { runCatching{repo.delete(item.medicine)};confirmDelete=false;onBack() }}){Text("Delete")}},dismissButton={TextButton(onClick={confirmDelete=false}){Text("Cancel")}})
}
@Composable fun HistoryScreen(medicines:List<MedicineWithSchedule>,repo:MedicineRepository) { var day by remember { mutableStateOf(LocalDate.now()) }; val from=day.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli(); val to=day.plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli(); val doses by repo.doses(from,to).collectAsStateWithLifecycle(initialValue=emptyList()); Column { Header("Medication history","Scheduled doses and recorded actions"); Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()){TextButton(onClick={day=day.minusDays(1)}){Text("‹ Previous")};Text(day.format(DateTimeFormatter.ofPattern("d MMM yyyy")),fontWeight=FontWeight.Bold);TextButton(onClick={day=day.plusDays(1)}){Text("Next ›")} }; if(doses.isEmpty()) Text("No dose records for this date.",color=Color.Gray) else LazyColumn { items(doses,key={it.id}){d-> SurfaceCard { Text(medicines.firstOrNull{it.medicine.id==d.medicineId}?.medicine?.name ?: "Medicine",fontWeight=FontWeight.Bold); Text("Scheduled: ${InstantFormat(d.scheduledAt)}"); Text("Status: ${d.status}"); d.confirmedAt?.let{Text("Confirmed: ${InstantFormat(it)}")}; if(d.skipReason.isNotBlank()) Text("Reason: ${d.skipReason}") } } } } }
@Composable fun SettingsScreen(settings:AppSettings,repo:MedicineRepository) { val scope= rememberCoroutineScope(); Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) { Header("Settings","Make reminders work for you"); SurfaceCard { Text("Reminder preferences",fontWeight=FontWeight.Bold,fontSize=18.sp); SettingSwitch("Reminder sound",settings.soundEnabled){scope.launch{repo.saveSettings(settings.copy(soundEnabled=it))}}; SettingSwitch("Vibration",settings.vibrationEnabled){scope.launch{repo.saveSettings(settings.copy(vibrationEnabled=it))}}; Text("Default snooze",fontWeight=FontWeight.Bold); ChoiceRow(listOf("5","10","15"),settings.snoozeMinutes.toString()){scope.launch{repo.saveSettings(settings.copy(snoozeMinutes=it.toInt()))}}; Text("minutes",fontSize=12.sp,color=Color.Gray); Text("Missed-dose grace period",fontWeight=FontWeight.Bold); ChoiceRow(listOf("15","30","60","120"),settings.graceMinutes.toString()){scope.launch{repo.saveSettings(settings.copy(graceMinutes=it.toInt()))}}; Text("minutes",fontSize=12.sp,color=Color.Gray); Text("Theme",fontWeight=FontWeight.Bold); ChoiceRow(listOf("System","Light","Dark"),settings.theme){scope.launch{repo.saveSettings(settings.copy(theme=it))}} }
        SurfaceCard { Text("Android permissions",fontSize=18.sp,fontWeight=FontWeight.Bold); Text("Notifications and exact alarms can be limited by Android or device battery settings."); val context=androidx.compose.ui.platform.LocalContext.current; Button(onClick={if(Build.VERSION.SDK_INT>=31){context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")))}else{context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:${context.packageName}"))) }},modifier=Modifier.fillMaxWidth()){Text("Reminder / alarm settings")}; OutlinedButton(onClick={context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,context.packageName))},modifier=Modifier.fillMaxWidth()){Text("Notification settings")} }
        SurfaceCard { Text("Privacy",fontWeight=FontWeight.Bold,fontSize=18.sp); Text("Your medicine details are stored locally on this device. MediReminder does not require an account or send medication data to a server."); Spacer(Modifier.height(8.dp)); Text("MediReminder v1.0",color=Color.Gray) }
    } }
@Composable fun SettingSwitch(label:String,checked:Boolean,onChange:(Boolean)->Unit){Row(Modifier.fillMaxWidth().heightIn(min=52.dp),verticalAlignment=Alignment.CenterVertically){Text(label,Modifier.weight(1f));Switch(checked=checked,onCheckedChange=onChange)}}
fun InstantFormat(ms:Long):String = java.time.Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("d MMM, HH:mm"))
