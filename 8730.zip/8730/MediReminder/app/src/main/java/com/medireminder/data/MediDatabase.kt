package com.medireminder.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Medicine::class, MedicationSchedule::class, DoseRecord::class, AppSettings::class], version = 1, exportSchema = false)
abstract class MediDatabase : RoomDatabase() {
    abstract fun medicineDao(): MedicineDao
    abstract fun doseDao(): DoseDao
    abstract fun settingsDao(): SettingsDao
    companion object {
        @Volatile private var INSTANCE: MediDatabase? = null
        fun get(context: Context): MediDatabase = INSTANCE ?: synchronized(this) { INSTANCE ?: Room.databaseBuilder(context.applicationContext, MediDatabase::class.java, "medireminder.db").build().also { INSTANCE = it } }
    }
}
